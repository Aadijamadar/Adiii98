import logo from './logo.svg';
import './App.css';
import LoginPage from './Components/loginpage';


function App() {
  return (
    <div >
      <LoginPage/>
    
    </div>
  );
}

export default App;
