import React from "react";
import './LoginPage.css'




const loginpage = () => {
    return(
        <div className="wrapper">
        <h1>Login</h1>
        <div className ="input-box">
            <input type="text" placeholder="email" required/>

        </div>
        <div className="input-box">
            <input type="password" placeholder="password" required/>
            
        </div>
        <button type="submit">login</button>
        </div>
    )
}
export default loginpage;